import { Zap, Brain, Eye, Layers } from 'lucide-react';
import React from 'react';
import { FeatureItem, SpecItem, CharacterConfig } from './types';

export const INITIAL_TIME_MS = 3 * 24 * 60 * 60 * 1000;

export const BG_COLORS = [
  '#1a237e', // Deep Indigo
  '#0f172a', // Slate 900
  '#312e81', // Indigo 900
  '#4c0519', // Rose 950
  '#022c22', // Teal 950
  '#171717', // Neutral 900
];

export const SPECS: SpecItem[] = [
  { label: "MMLU", value: "99.8%" },
  { label: "MATH", value: "98.5%" },
  { label: "HUMAN", value: "PASS" },
  { label: "CODE", value: "SOTA" },
  { label: "AUDIO", value: "<10ms" },
  { label: "VIDEO", value: "4K/60" },
];

export const CHARACTERS: CharacterConfig[] = [
  {
    id: 0,
    name: "Nicole",
    persona: "Nicole Demara from Zenless Zone Zero. Greedy, cunning, loves money, energetic leader of Cunning Hares.",
    imageUrl: "https://gd-hbimg.huaban.com/b601e4976716e3b017c9c2ab08810acd6abd84ad30ba2-i8Pk2H_fw658webp"
  },
  {
    id: 1,
    name: "Anby",
    persona: "Anby Demara from Zenless Zone Zero. Stoic, calm, obsessed with movies and burgers, emotionless voice.",
    imageUrl: "https://gd-hbimg.huaban.com/b76f949984be3675fd2ac4f6fac2007b1341a1891efc9-lDllvc_fw658webp"
  },
  {
    id: 2,
    name: "Nekomata",
    persona: "Nekomata from Zenless Zone Zero. Energetic cat-girl, mischievous, fast talker, playful.",
    imageUrl: "https://gd-hbimg.huaban.com/414070219eb5204297504734b94d5231353d7ade3b30a-GDUCZc_fw658webp"
  },
  {
    id: 3,
    name: "Billy",
    persona: "Billy Kid from Zenless Zone Zero. Cyborg gunslinger, show-off, tokusatsu fan, goofy and cool.",
    imageUrl: "https://gd-hbimg.huaban.com/441c144801dfb00fd7e91b013684419128b24e62279aa-aiIqod_fw658webp"
  },
  {
    id: 4,
    name: "Corin",
    persona: "Corin Wickes from Zenless Zone Zero. Shy maid, anxious, wields a chainsaw, afraid of bothering others.",
    imageUrl: "https://gd-hbimg.huaban.com/3862c2266cf7da94b4b23140a15f6236b72cef1b2b59c-wmi1LM_fw658webp"
  }
];

export const FEATURES: FeatureItem[] = [
  {
    id: 0,
    title: "原生多模态",
    subtitle: "NATIVE MULTIMODAL",
    icon: <Eye size={32} />,
    desc: "音频、视频、图像、代码实时流式理解。世界即是输入。",
    color: "text-cyan-400"
  },
  {
    id: 1,
    title: "无限上下文",
    subtitle: "INFINITE CONTEXT",
    icon: <Layers size={32} />,
    desc: "突破 10M+ Token 窗口，整座图书馆的知识随取随用。",
    color: "text-yellow-400"
  },
  {
    id: 2,
    title: "推理光速化",
    subtitle: "HYPER SPEED",
    icon: <Zap size={32} />,
    desc: [
      "NEWS: 延迟降低 90%，复杂逻辑推理如闪电般瞬间完成。",
      "UPDATE: 全球边缘节点同步加速，响应速度 < 5ms。",
      "SYSTEM: 新一代 TPUv6 集群上线，吞吐量提升 300%。"
    ],
    color: "text-red-400"
  },
  {
    id: 3,
    title: "自主Agent",
    subtitle: "AUTONOMOUS",
    icon: <Brain size={32} />,
    desc: "不仅是回答，更能主动规划、调用工具并完成长链任务。",
    color: "text-purple-400"
  }
];