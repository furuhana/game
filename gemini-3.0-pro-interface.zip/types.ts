import { ReactNode } from 'react';

export interface FeatureItem {
  id: number;
  title: string;
  subtitle: string;
  icon: ReactNode;
  desc: string | string[];
  color: string;
}

export interface SpecItem {
  label: string;
  value: string;
}

export interface Position {
  x: number;
  y: number;
}

export interface CharacterConfig {
  id: number;
  name: string;
  persona: string;
  imageUrl: string;
}

export type BgColor = string;