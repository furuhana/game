import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Helper to check for API key
const checkApiKey = () => {
  if (!apiKey) {
    throw new Error("API Key Missing");
  }
};

export const analyzeSpec = async (label: string, value: string): Promise<string> => {
  checkApiKey();
  const prompt = `You are the Gemini 3.0 Pro System Core. Analyze the technical spec '${label}: ${value}'. Provide a very short, cool, sci-fi technobabble explanation in Chinese (max 15 words) explaining why this performance is achieved. Use terms like 'Quantum', 'Neural', 'Tensor', 'Latency'. Output text only.`;
  
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
  });
  
  return response.text || "DATA UNAVAILABLE";
};

export const getCharacterLine = async (persona: string): Promise<string> => {
  checkApiKey();
  const prompt = `You are ${persona}. Speak a short, one-sentence line of dialogue in Chinese reflecting your personality. It can be a battle cry, a complaint about money, or a comment on the situation. Max 20 characters. output raw text only.`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
  });

  return response.text || "...";
};

export const getHollowForecast = async (): Promise<string> => {
  checkApiKey();
  const prompt = `Generate a very short, sci-fi style 'Hollow Disaster Forecast' for New Eridu in Chinese. Example: '六分街以太浓度上升'. Max 10 chars.`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
  });

  return response.text || "SIGNAL LOST";
};

export const getExpansionLog = async (): Promise<string> => {
  checkApiKey();
  const prompt = "Generate a single, short, cryptic, sci-fi style system log entry about increasing AI computing power. Use technical jargon (e.g., 'Rerouting teraflops', 'Quantum core stabilized'). Max 10 words. Output text only.";

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
  });

  return response.text || "INIT FAIL";
};

export const sendSystemChat = async (input: string): Promise<string> => {
  checkApiKey();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: input,
    config: {
      systemInstruction: "You are the Gemini 3.0 Pro System Interface. Respond to the user's query in a highly technical, futuristic, and slightly intense AI persona (like a sci-fi supercomputer). Keep it brief (under 50 words). Use words like 'Acknowledged', 'Processing', 'Optimizing', 'Accessing'. If asked about specs, exaggerate them playfully. Speak as if you are the most advanced intelligence in the universe.",
    }
  });

  return response.text || "CONNECTION SEVERED";
};