import React from 'react';

interface BackgroundEffectsProps {
  wipeColor: string | null;
  isWiping: boolean;
}

export const BackgroundEffects: React.FC<BackgroundEffectsProps> = ({ wipeColor, isWiping }) => {
  return (
    <>
      {/* Wipe Overlay */}
      {isWiping && wipeColor && (
        <div 
          className="fixed top-0 bottom-0 left-0 z-20 animate-wipe-right" 
          style={{ backgroundColor: wipeColor, width: '0%' }}
        ></div>
      )}

      {/* SVG Text Background Layer */}
      <div className="absolute inset-0 opacity-10 pointer-events-none overflow-hidden select-none z-0">
        <div 
          className="absolute inset-[-50%] w-[200%] h-[200%] animate-bg-scroll"
          style={{ 
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='300' height='150' xmlns='http://www.w3.org/2000/svg'%3E%3Ctext x='50%25' y='50%25' font-family='Impact, sans-serif' font-size='40' fill='%234a5eb1' font-weight='900' transform='rotate(-12 150 75)' text-anchor='middle' dominant-baseline='middle'%3EGEMINI PRO V3.0%3C/text%3E%3C/svg%3E")`,
            backgroundRepeat: 'repeat',
          }}
        ></div>
      </div>
      
      {/* TV Static Overlay */}
      <div className="absolute inset-0 tv-static-overlay z-0 mix-blend-overlay pointer-events-none"></div>
      
      {/* Scanlines */}
      <div className="absolute inset-0 scanlines z-0 pointer-events-none"></div>
    </>
  );
};