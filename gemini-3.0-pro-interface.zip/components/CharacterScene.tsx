import React, { useEffect, useRef } from 'react';
import { Sparkles } from 'lucide-react';
import { CHARACTERS } from '../constants';
import { Position } from '../types';

interface CharacterSceneProps {
  commMessages: Record<number, string>;
  loadingCommIndex: number | null;
  onCharacterClick: (index: number) => void;
}

export const CharacterScene: React.FC<CharacterSceneProps> = ({ 
  commMessages, 
  loadingCommIndex, 
  onCharacterClick 
}) => {
  const imageRefs = useRef<(HTMLImageElement | null)[]>([]);
  const currentPositions = useRef<Position[]>(Array(5).fill({ x: 0, y: 0 }));
  const targetPosition = useRef<Position>({ x: 0, y: 0 });
  const rafId = useRef<number | null>(null);

  // Linear interpolation
  const lerp = (start: number, end: number, factor: number) => {
    return start + (end - start) * factor;
  };

  useEffect(() => {
    const handleMouseMove = (event: MouseEvent) => {
      const { innerWidth, innerHeight } = window;
      const moveX = (event.clientX - innerWidth / 2) / (innerWidth / 2) * 30;
      const moveY = (event.clientY - innerHeight / 2) / (innerHeight / 2) * 30;
      targetPosition.current = { x: -moveX, y: -moveY };
    };

    const animate = () => {
      for (let i = 0; i < CHARACTERS.length; i++) {
        const imgRef = imageRefs.current[i];
        if (!imgRef) continue;

        const current = currentPositions.current[i];
        const target = targetPosition.current;
        // Parallax speed varies per layer
        const speed = 0.08 - (i * 0.012);

        const newX = lerp(current.x, target.x, speed);
        const newY = lerp(current.y, target.y, speed);

        currentPositions.current[i] = { x: newX, y: newY };
        imgRef.style.transform = `translate3d(${newX}px, ${newY}px, 0)`;
      }
      rafId.current = requestAnimationFrame(animate);
    };

    window.addEventListener('mousemove', handleMouseMove);
    rafId.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      if (rafId.current) cancelAnimationFrame(rafId.current);
    };
  }, []);

  return (
    <div className="fixed bottom-0 left-0 w-full h-full z-[1] flex justify-center items-end pb-4 md:pb-10 gap-2 md:gap-8 pointer-events-none">
      {CHARACTERS.map((char, index) => (
        <div key={char.id} className="relative pointer-events-auto group">
          {/* Comm Bubble */}
          {(commMessages[index] || loadingCommIndex === index) && (
            <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-48 z-50 animate-pop-in">
              <div className="bg-white border-4 border-black p-3 rounded-xl shadow-[4px_4px_0px_#000] relative">
                <div className="text-xs font-black leading-tight text-center text-black">
                  {loadingCommIndex === index ? (
                    <span className="flex items-center justify-center gap-1">
                      <Sparkles size={12} className="animate-spin text-yellow-500" />
                      信号接入中...
                    </span>
                  ) : (
                    commMessages[index]
                  )}
                </div>
                {/* Bubble Tail */}
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-white border-b-4 border-r-4 border-black rotate-45"></div>
              </div>
            </div>
          )}
          
          <img
            ref={(el) => (imageRefs.current[index] = el)}
            src={char.imageUrl}
            alt={char.name}
            onError={(e) => {
               // Fallback if hotlink protection blocks the image
               (e.target as HTMLImageElement).src = `https://picsum.photos/400/800?random=${index}`;
            }}
            onClick={() => onCharacterClick(index)}
            className="w-[18vw] md:w-auto h-auto md:h-[45vh] object-contain will-change-transform cursor-pointer hover:brightness-110 active:scale-95 transition-filter duration-200"
          />
        </div>
      ))}
    </div>
  );
};