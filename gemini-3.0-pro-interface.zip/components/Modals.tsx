import React from 'react';
import { AlertTriangle, CheckCircle, Brain, X, Send, Cpu, Sparkles } from 'lucide-react';

interface ProModalProps {
  onClose: () => void;
}

export const ProModal: React.FC<ProModalProps> = ({ onClose }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
    <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-0" onClick={onClose}></div>
    <div className="absolute inset-0 tv-static-overlay z-0 mix-blend-overlay pointer-events-none"></div>
    <div className="bg-[#f0f0f2] w-full max-w-md rounded-[2rem] border-[8px] border-[#2a2a2a] shadow-[0_0_0_1000px_rgba(0,0,0,0.5)] relative overflow-hidden transform transition-all scale-100 animate-in zoom-in-95 duration-200 z-10 border-white/50 ring-4 ring-white/50">
      <div className="bg-[#ffcc00] p-4 border-b-4 border-black flex items-center gap-3">
        <AlertTriangle className="text-black fill-current" size={32} />
        <div className="font-black text-2xl tracking-tighter italic text-black">SYSTEM ALERT</div>
      </div>
      <div className="p-8 text-center relative">
        <h3 className="text-3xl font-black text-[#1a237e] mb-2 uppercase italic">Pro Access</h3>
        <p className="text-gray-600 font-bold mb-8 border-y-2 border-gray-300 py-4">
          正在接入高维神经算力网络。<br />
          检测到非线性时间流波动。<br />
          <span className="text-red-600">是否立即同步 Gemini 3.0 Pro 核心？</span>
        </p>
        <div className="flex gap-4 justify-center">
          <button onClick={onClose} className="px-6 py-3 rounded-xl border-4 border-gray-400 font-black text-gray-500 hover:bg-gray-200 transition-colors">
            CANCEL
          </button>
          <button onClick={onClose} className="px-8 py-3 rounded-xl border-4 border-black bg-[#ff3333] text-white font-black shadow-[4px_4px_0px_#000] hover:translate-x-1 hover:translate-y-1 hover:shadow-none transition-all flex items-center gap-2">
            <CheckCircle size={20} /> CONFIRM
          </button>
        </div>
      </div>
      <div className="h-4 bg-black w-full absolute bottom-0" style={{ backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, #333 10px, #333 20px)' }}></div>
    </div>
  </div>
);

interface LoadingModalProps {
  onClose: () => void;
}

export const LoadingModal: React.FC<LoadingModalProps> = ({ onClose }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
    <div className="bg-white w-full max-w-sm rounded-[2rem] border-8 border-black shadow-[0_0_0_1000px_rgba(0,0,0,0.8)] relative overflow-hidden flex flex-col items-center">
      <div className="p-10 flex flex-col items-center justify-center w-full min-h-[300px]">
        <div className="flex items-end gap-2 mb-8 animate-bounce-custom">
          <div className="font-black text-6xl italic tracking-tighter text-black font-sans">NOW</div>
          <div className="w-16 h-20 bg-black rounded-t-3xl rounded-b-xl relative mb-1">
            <div className="absolute -top-4 left-2 w-3 h-6 bg-black rounded-full rotate-[-10deg]"></div>
            <div className="absolute -top-4 right-2 w-3 h-6 bg-black rounded-full rotate-[10deg]"></div>
            <div className="absolute top-6 left-3 w-4 h-4 bg-white rounded-full"></div>
            <div className="absolute top-6 right-3 w-4 h-4 bg-white rounded-full"></div>
          </div>
        </div>
        <div className="font-black text-4xl italic tracking-widest text-black mb-8 border-b-4 border-black w-full text-center pb-2 font-sans">
          LOADING...
        </div>
        <button onClick={onClose} className="w-full py-4 rounded-xl border-4 border-black bg-[#ffcc00] text-black font-black text-xl shadow-[4px_4px_0px_#000] hover:translate-x-1 hover:translate-y-1 hover:shadow-none transition-all flex items-center justify-center gap-2 uppercase">
          <CheckCircle size={24} className="stroke-[3]" /> Confirm
        </button>
      </div>
      <div className="h-6 bg-black w-full absolute bottom-0 flex">
        {Array.from({ length: 20 }).map((_, i) => (
          <div key={i} className="flex-1 border-r border-gray-800"></div>
        ))}
      </div>
    </div>
  </div>
);

interface ChatModalProps {
  onClose: () => void;
  chatInput: string;
  setChatInput: (val: string) => void;
  chatResponse: string;
  isThinking: boolean;
  onSend: () => void;
}

export const ChatModal: React.FC<ChatModalProps> = ({ 
  onClose, chatInput, setChatInput, chatResponse, isThinking, onSend 
}) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
    <div className="bg-[#2a2a2a] w-full max-w-lg rounded-[2rem] border-8 border-[#ffcc00] shadow-[0_0_0_1000px_rgba(0,0,0,0.8)] relative overflow-hidden flex flex-col">
      <div className="bg-[#ffcc00] p-4 flex justify-between items-center border-b-4 border-black">
        <div className="flex items-center gap-2">
          <Brain className="text-black" size={28} />
          <div className="font-black text-xl text-black uppercase italic tracking-tighter">Neural Link v3.0</div>
        </div>
        <button onClick={onClose} className="bg-black text-[#ffcc00] p-1 rounded hover:bg-gray-800"><X size={20} /></button>
      </div>
      <div className="p-6 flex-1 flex flex-col gap-4 min-h-[300px]">
        <div className="flex-1 bg-[#1a1a1a] rounded-xl p-4 border-2 border-[#444] font-mono text-green-400 text-sm md:text-base leading-relaxed overflow-y-auto shadow-inner relative h-64">
          <div className="absolute top-2 right-2 opacity-50"><Cpu size={16} /></div>
          {isThinking ? (
            <div className="flex items-center gap-2 text-[#ffcc00] animate-pulse">
              <Sparkles size={16} />
              <span>NEURAL ENGINE COMPUTING...</span>
            </div>
          ) : (
            <div className="typing-effect whitespace-pre-wrap">{chatResponse}</div>
          )}
        </div>
        <div className="flex gap-2">
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && onSend()}
            placeholder="Query the system..."
            className="flex-1 bg-[#f0f0f2] border-4 border-[#555] rounded-xl px-4 py-3 font-bold text-black focus:outline-none focus:border-[#ffcc00] placeholder:text-gray-400 uppercase"
          />
          <button
            onClick={onSend}
            disabled={isThinking}
            className="bg-[#ffcc00] border-4 border-black rounded-xl px-4 text-black hover:bg-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send size={24} className="stroke-[3]" />
          </button>
        </div>
      </div>
      <div className="h-2 bg-black w-full"></div>
    </div>
  </div>
);