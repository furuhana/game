import React, { useState, useEffect } from 'react';
import { 
  Zap, Brain, Eye, Layers, ArrowRight, X, RotateCcw, Menu, Cpu, 
  Terminal, ChevronLeft, ChevronRight, Radio, RefreshCw 
} from 'lucide-react';
import { FEATURES, SPECS, BG_COLORS, INITIAL_TIME_MS, CHARACTERS } from './constants';
import { analyzeSpec, getCharacterLine, getHollowForecast, getExpansionLog, sendSystemChat } from './services/geminiService';
import { BackgroundEffects } from './components/BackgroundEffects';
import { CharacterScene } from './components/CharacterScene';
import { ProModal, LoadingModal, ChatModal } from './components/Modals';

export default function Gemini3ProShowcase() {
  // UI State
  const [activeFeature, setActiveFeature] = useState(0);
  const [newsIndex, setNewsIndex] = useState(0);
  
  // Feature States
  const [timeLeft, setTimeLeft] = useState(INITIAL_TIME_MS);
  const [showModal, setShowModal] = useState(false);
  const [showLoading, setShowLoading] = useState(false);
  const [showResetToast, setShowResetToast] = useState(false);
  const [activeSpecIndex, setActiveSpecIndex] = useState<number | null>(null);

  // Gemini Interaction States
  const [showChat, setShowChat] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [chatResponse, setChatResponse] = useState("SYSTEM READY. WAITING FOR INPUT...");
  const [isThinking, setIsThinking] = useState(false);
  
  const [expansionLog, setExpansionLog] = useState("");
  const [isExpanding, setIsExpanding] = useState(false);
  
  const [commMessages, setCommMessages] = useState<Record<number, string>>({});
  const [loadingCommIndex, setLoadingCommIndex] = useState<number | null>(null);
  
  const [forecast, setForecast] = useState("");
  const [isForecasting, setIsForecasting] = useState(false);
  
  const [specAnalysis, setSpecAnalysis] = useState("");
  const [isAnalyzingSpec, setIsAnalyzingSpec] = useState(false);

  // Background/Theme State
  const [bgColorIndex, setBgColorIndex] = useState(0);
  const [activeBgColor, setActiveBgColor] = useState(BG_COLORS[0]);
  const [wipeColor, setWipeColor] = useState<string | null>(null);
  const [isWiping, setIsWiping] = useState(false);
  const [colorCodeText, setColorCodeText] = useState("");

  // --- Effects ---

  // Countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => Math.max(0, prev - 60000));
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  // News Ticker
  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | undefined;
    const currentDesc = FEATURES[activeFeature].desc;
    if (Array.isArray(currentDesc)) {
      interval = setInterval(() => {
        setNewsIndex((prev) => (prev + 1) % currentDesc.length);
      }, 3000);
    } else {
      setNewsIndex(0);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [activeFeature]);

  // RGB Typewriter
  useEffect(() => {
    const targetText = `HEX: ${BG_COLORS[bgColorIndex]}`;
    let i = 0;
    setColorCodeText("");
    const interval = setInterval(() => {
      setColorCodeText(targetText.substring(0, i + 1));
      i++;
      if (i > targetText.length) clearInterval(interval);
    }, 50);
    return () => clearInterval(interval);
  }, [bgColorIndex]);

  // --- Handlers ---

  const handleReset = () => {
    setTimeLeft(INITIAL_TIME_MS);
    setShowResetToast(true);
    setTimeout(() => setShowResetToast(false), 2000);
  };

  const handleColorChange = (direction: 'next' | 'prev') => {
    if (isWiping) return;
    let newIndex;
    if (direction === 'next') {
      newIndex = (bgColorIndex + 1) % BG_COLORS.length;
    } else {
      newIndex = (bgColorIndex - 1 + BG_COLORS.length) % BG_COLORS.length;
    }
    const nextColor = BG_COLORS[newIndex];
    setWipeColor(nextColor);
    setIsWiping(true);
    setBgColorIndex(newIndex);
    setTimeout(() => {
      setActiveBgColor(nextColor);
      setIsWiping(false);
      setWipeColor(null);
    }, 500);
  };

  const cycleNews = (direction: 'next' | 'prev') => {
    const currentDesc = FEATURES[activeFeature].desc;
    if (Array.isArray(currentDesc)) {
      if (direction === 'next') {
        setNewsIndex((prev) => (prev + 1) % currentDesc.length);
      } else {
        setNewsIndex((prev) => (prev - 1 + currentDesc.length) % currentDesc.length);
      }
    }
  };

  const formatTime = (ms: number) => {
    const days = Math.floor(ms / (1000 * 60 * 60 * 24));
    const hours = Math.floor((ms % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    return `${String(days).padStart(2, '0')}天 ${String(hours).padStart(2, '0')}时 ${String(minutes).padStart(2, '0')}分`;
  };

  // --- API Handlers ---

  const handleSpecClick = async (index: number) => {
    setActiveSpecIndex(index);
    setTimeout(() => setActiveSpecIndex(null), 300);
    if (isAnalyzingSpec) return;
    setIsAnalyzingSpec(true);
    setSpecAnalysis("ANALYZING DATA STREAM...");
    
    try {
      const spec = SPECS[index];
      const result = await analyzeSpec(spec.label, spec.value);
      setSpecAnalysis(result);
      setTimeout(() => setSpecAnalysis(""), 5000);
    } catch (error) {
      console.error(error);
      setSpecAnalysis("DATA CORRUPTION");
    } finally {
      setIsAnalyzingSpec(false);
    }
  };

  const handleCharacterClick = async (index: number) => {
    if (loadingCommIndex !== null) return;
    setLoadingCommIndex(index);
    setCommMessages(prev => ({ ...prev, [index]: "" }));
    
    try {
      const persona = CHARACTERS[index].persona;
      const text = await getCharacterLine(persona);
      setCommMessages(prev => ({ ...prev, [index]: text }));
      setTimeout(() => {
        setCommMessages(prev => {
          const newState = { ...prev };
          delete newState[index];
          return newState;
        });
      }, 5000);
    } catch (error) {
      setCommMessages(prev => ({ ...prev, [index]: "通讯受干扰..." }));
    } finally {
      setLoadingCommIndex(null);
    }
  };

  const handleForecast = async () => {
    if (isForecasting) return;
    setIsForecasting(true);
    setForecast("获取新艾利都天气中...");
    try {
      const text = await getHollowForecast();
      setForecast(text);
      setTimeout(() => {
        setForecast("");
        setIsForecasting(false);
      }, 4000);
    } catch (error) {
      setForecast("信号丢失");
      setTimeout(() => setIsForecasting(false), 2000);
    }
  };

  const handleSystemChat = async () => {
    if (!chatInput.trim()) return;
    setIsThinking(true);
    setChatResponse("PROCESSING NEURAL REQUEST...");
    try {
      const text = await sendSystemChat(chatInput);
      setChatResponse(text);
    } catch (error) {
      setChatResponse("ERROR: NEURAL LINK CONNECTION FAILED. (CHECK API KEY)");
    } finally {
      setIsThinking(false);
      setChatInput("");
    }
  };

  const handleExpansion = async () => {
    if (isExpanding) return;
    setIsExpanding(true);
    setExpansionLog("INITIALIZING EXPANSION PROTOCOL...");
    try {
      const text = await getExpansionLog();
      setExpansionLog(text);
      setTimeout(() => setExpansionLog(""), 4000);
    } catch (error) {
      setExpansionLog("EXPANSION FAILED");
    } finally {
      setTimeout(() => setIsExpanding(false), 4000);
    }
  };

  return (
    <div 
      className="min-h-screen p-4 md:p-8 font-sans overflow-hidden relative selection:bg-yellow-400 selection:text-black transition-colors duration-0"
      style={{ backgroundColor: activeBgColor }}
    >
       {/* Global Animation Styles */}
      <style>{`
        @keyframes slide-stripes { 0% { background-position: 0 0; } 100% { background-position: 56px 0; } }
        .animate-stripes { animation: slide-stripes 1s linear infinite; }
        @keyframes fade-in-up { 0% { opacity: 0; transform: translateY(10px); } 100% { opacity: 1; transform: translateY(0); } }
        .animate-text-change { animation: fade-in-up 0.3s ease-out forwards; }
        @keyframes background-scroll { 0% { background-position: 0 0; } 100% { background-position: 300px 150px; } }
        .animate-bg-scroll { animation: background-scroll 20s linear infinite; }
        @keyframes bounce-custom { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-25%); } }
        .animate-bounce-custom { animation: bounce-custom 0.6s infinite ease-in-out; }
        @keyframes wipe-right { 0% { width: 0; left: 0; } 100% { width: 100%; left: 0; } }
        .animate-wipe-right { animation: wipe-right 0.5s cubic-bezier(0.77, 0, 0.175, 1) forwards; }
        @keyframes noise { 0%, 100% { background-position: 0 0; } 10% { background-position: -5% -10%; } 20% { background-position: -15% 5%; } 30% { background-position: 7% -25%; } 40% { background-position: 20% 25%; } 50% { background-position: -25% 10%; } 60% { background-position: 15% 5%; } 70% { background-position: 0% 15%; } 80% { background-position: 25% 35%; } 90% { background-position: -10% 10%; } }
        .tv-static-overlay { background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='0.4'/%3E%3C/svg%3E"); animation: noise 0.2s steps(3) infinite; opacity: 0.15; pointer-events: none; }
        .scanlines { background: linear-gradient( to bottom, rgba(255,255,255,0), rgba(255,255,255,0) 50%, rgba(0,0,0,0.2) 50%, rgba(0,0,0,0.2) ); background-size: 100% 4px; }
        @keyframes toast-slide-down { 0% { transform: translate(-50%, -100%); opacity: 0; } 20% { transform: translate(-50%, 20px); opacity: 1; } 80% { transform: translate(-50%, 20px); opacity: 1; } 100% { transform: translate(-50%, -100%); opacity: 0; } }
        .animate-toast { animation: toast-slide-down 2s ease-in-out forwards; }
        @keyframes subtle-blink { 0% { opacity: 1; filter: brightness(1); } 50% { opacity: 0.7; filter: brightness(1.5) hue-rotate(90deg); background-color: #333; } 100% { opacity: 1; filter: brightness(1); } }
        .animate-subtle-blink { animation: subtle-blink 0.3s ease-in-out; }
        @keyframes pop-in { 0% { transform: scale(0) translateY(20px); opacity: 0; } 80% { transform: scale(1.1) translateY(-5px); opacity: 1; } 100% { transform: scale(1) translateY(0); opacity: 1; } }
        .animate-pop-in { animation: pop-in 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards; }
      `}</style>

      {showResetToast && (
        <div className="fixed top-0 left-1/2 z-[100] bg-white border-4 border-black px-6 py-3 rounded-b-xl shadow-[4px_4px_0px_#000] flex items-center gap-2 animate-toast">
          <RefreshCw size={20} className="animate-spin" />
          <span className="font-black text-lg italic uppercase">已重置</span>
        </div>
      )}

      <BackgroundEffects wipeColor={wipeColor} isWiping={isWiping} />
      
      <CharacterScene 
        commMessages={commMessages} 
        loadingCommIndex={loadingCommIndex} 
        onCharacterClick={handleCharacterClick} 
      />

      {/* Modals */}
      {showModal && <ProModal onClose={() => setShowModal(false)} />}
      {showLoading && <LoadingModal onClose={() => setShowLoading(false)} />}
      {showChat && (
        <ChatModal 
          onClose={() => setShowChat(false)}
          chatInput={chatInput}
          setChatInput={setChatInput}
          chatResponse={chatResponse}
          isThinking={isThinking}
          onSend={handleSystemChat}
        />
      )}

      {/* Main Interface */}
      <div className="max-w-6xl mx-auto h-full flex flex-col md:flex-row gap-8 items-center justify-center relative z-10 mt-8 mb-8">
        
        {/* LEFT PANEL */}
        <div className="w-full md:w-3/5 bg-[#f0f0f2] rounded-[3rem] border-8 border-[#e0e0e5] shadow-[16px_16px_0px_rgba(0,0,0,1)] relative overflow-hidden transition-transform duration-300 hover:-translate-y-1">
          {/* Top Bar */}
          <div className="bg-white p-10 flex justify-between items-center border-b-4 border-[#e0e0e5] flex-wrap gap-4">
            <div className="flex items-center gap-2">
              <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center text-white transform rotate-3 shadow-[4px_4px_0px_#000000] border-2 border-transparent">
                <Cpu size={24} />
              </div>
              <div className="leading-none ml-2">
                <div className="text-xs font-bold text-gray-500">SYSTEM</div>
                <div className="text-2xl font-black italic tracking-tighter text-[#2a2a2a]">G-3.0 PRO</div>
              </div>
            </div>
            
            {/* Forecast Area */}
            <div 
              onClick={handleForecast} 
              className="bg-[#2a2a2a] text-white px-4 py-2 rounded-full font-mono text-sm flex items-center gap-2 border-2 border-black shadow-[inset_0px_0px_0px_rgba(0,0,0,0)] min-w-[220px] justify-center cursor-pointer hover:bg-black transition-colors"
            >
              {isForecasting ? (
                <span className="flex items-center gap-2 animate-pulse text-[#ffcc00]">
                  <Radio size={16} className="animate-ping" />
                  {forecast || "SIGNAL SEEKING..."}
                </span>
              ) : (
                <>
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                  发布倒计时: {formatTime(timeLeft)}
                </>
              )}
            </div>
          </div>

          {/* Features Grid */}
          <div className="p-6 bg-[#2a2a2a] m-4 rounded-[2rem] shadow-[inset_4px_4px_0px_rgba(0,0,0,0.5)] relative border-4 border-[#333]">
            <div className="absolute -left-6 top-10 z-20 transform -rotate-12 bg-[#ffcc00] border-4 border-black text-black font-black px-4 py-2 text-xl shadow-[6px_6px_0px_#000000]">
              <span className="block transform skew-x-12">NEXT GEN</span>
              <span className="text-xs font-bold bg-black text-white px-1 block transform -skew-x-12 mt-1 text-center border border-black">AI MODEL</span>
            </div>
            <div className="grid grid-cols-2 gap-4 h-96">
              {FEATURES.map((item, idx) => (
                <button 
                  key={idx} 
                  onClick={() => setActiveFeature(idx)}
                  className={`group relative rounded-2xl border-4 transition-all duration-200 overflow-hidden flex flex-col items-center justify-center p-4 
                    ${activeFeature === idx ? 'bg-[#3a3a3a] border-[#ffcc00] shadow-[6px_6px_0px_#ffcc00] translate-x-[-2px] translate-y-[-2px]' : 'bg-[#1a1a1a] border-[#444] hover:border-[#666] shadow-[4px_4px_0px_#000]'}
                  `}
                >
                  <div className={`absolute inset-0 opacity-20 pointer-events-none stripes-bg transition-opacity duration-300 ${activeFeature === idx ? 'opacity-30' : 'group-hover:opacity-30 group-hover:animate-stripes'}`}
                    style={{ backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, #000 10px, #000 20px)', backgroundSize: '28.28px 28.28px' }}>
                  </div>
                  <div className={`mb-3 transition-transform duration-300 group-hover:scale-110 relative z-10 ${activeFeature === idx ? item.color : 'text-gray-600'}`}>
                    {item.icon}
                  </div>
                  <div className="text-center relative z-10">
                    <div className={`font-black text-lg md:text-xl uppercase italic ${activeFeature === idx ? 'text-white' : 'text-gray-500'}`}>
                      {item.title}
                    </div>
                  </div>
                  {activeFeature === idx && (
                    <div className="absolute top-2 right-2 w-3 h-3 bg-[#ffcc00] rounded-full border border-black shadow-[2px_2px_0px_#000]"></div>
                  )}
                </button>
              ))}
            </div>

            {/* Description Box */}
            <div className="mt-4 bg-[#1a1a1a] rounded-xl p-4 border-2 border-[#444] flex items-center gap-4 min-h-[80px] shadow-[4px_4px_0px_#000] relative overflow-hidden">
              <div className="absolute inset-0 pointer-events-none opacity-5" style={{ background: 'linear-gradient(to bottom, transparent 50%, rgba(255,255,255,0.1) 50%)', backgroundSize: '100% 4px' }}></div>
              <div className="text-[#ffcc00] font-mono text-3xl font-bold shadow-black drop-shadow-[2px_2px_0px_rgba(0,0,0,1)] min-w-[3rem]">
                0{activeFeature + 1}
              </div>
              <div className="flex-1 z-10 overflow-hidden">
                <div className="text-gray-400 text-xs font-bold tracking-widest mb-1">{FEATURES[activeFeature].subtitle}</div>
                {Array.isArray(FEATURES[activeFeature].desc) ? (
                  <div className="relative h-10 flex items-center">
                    <div key={newsIndex} className="text-white text-sm md:text-base font-medium leading-tight animate-text-change">
                      {(FEATURES[activeFeature].desc as string[])[newsIndex]}
                    </div>
                  </div>
                ) : (
                  <div className="text-white text-sm md:text-base font-medium leading-tight animate-text-change">
                    {FEATURES[activeFeature].desc as string}
                  </div>
                )}
              </div>
              {Array.isArray(FEATURES[activeFeature].desc) ? (
                <div className="flex gap-1 z-20">
                  <button onClick={(e) => { e.stopPropagation(); cycleNews('prev'); }} className="p-1 hover:bg-[#333] rounded text-[#ffcc00] transition-colors"><ChevronLeft size={20}/></button>
                  <button onClick={(e) => { e.stopPropagation(); cycleNews('next'); }} className="p-1 hover:bg-[#333] rounded text-[#ffcc00] transition-colors"><ChevronRight size={20}/></button>
                </div>
              ) : (
                <ArrowRight className="text-[#ffcc00] animate-pulse" />
              )}
            </div>
          </div>
        </div>

        {/* RIGHT PANEL */}
        <div className="w-full md:w-2/5 flex flex-col gap-6">
          <div className="flex justify-end gap-4">
            <button onClick={handleReset} className="w-16 h-16 rounded-full bg-[#ff3333] border-4 border-[#2a2a2a] shadow-[6px_6px_0px_#000] flex items-center justify-center text-white hover:translate-y-1 hover:translate-x-1 hover:shadow-none transition-all active:bg-red-600 active:scale-95" title="Reset Timer">
              <RotateCcw size={28} strokeWidth={3} />
            </button>
            <button onClick={() => setShowLoading(true)} className="w-16 h-16 rounded-full bg-[#ff3333] border-4 border-[#2a2a2a] shadow-[6px_6px_0px_#000] flex items-center justify-center text-white hover:translate-y-1 hover:translate-x-1 hover:shadow-none transition-all active:bg-red-600">
              <Menu size={28} strokeWidth={3} />
            </button>
          </div>

          <div className="bg-[#4a4a5e] rounded-[2rem] p-2 shadow-[12px_12px_0px_#000000] border-4 border-[#2a2a2a] relative">
            <div className="absolute -top-5 left-8 bg-[#808080] text-[#2a2a2a] px-4 py-1 rounded-t-lg font-bold text-sm border-t-4 border-x-4 border-[#2a2a2a]">
              核心参数库
            </div>
            <div className="absolute top-4 right-4 text-[#ff3333] opacity-80 font-black text-4xl transform -rotate-12 pointer-events-none z-20" style={{ textShadow: '2px 2px 0px #000' }}>
              TOP SPEC
            </div>
            <div className="bg-[#5a5a6e] rounded-[1.5rem] p-4 border-2 border-[#3a3a4a]">
              <div className="grid grid-cols-3 gap-2">
                {SPECS.map((spec, idx) => (
                  <div 
                    key={idx} 
                    onClick={() => handleSpecClick(idx)}
                    className={`aspect-square bg-[#3a3a4a] rounded-xl relative group hover:bg-[#2a2a2a] transition-all border-2 border-[#2a2a2a] flex flex-col items-center justify-center cursor-pointer overflow-visible shadow-[2px_2px_0px_rgba(0,0,0,0.5)] active:scale-95 select-none ${activeSpecIndex === idx ? 'animate-subtle-blink' : ''}`}
                  >
                    <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none">
                      <X size={64} />
                    </div>
                    <div className="text-gray-400 text-[10px] font-bold tracking-widest mb-1 z-10">{spec.label}</div>
                    <div className="text-white font-black text-xl z-10 group-hover:text-[#ffcc00] transition-colors drop-shadow-[2px_2px_0px_rgba(0,0,0,1)]">{spec.value}</div>
                    
                    {/* Spec Analysis Popover */}
                    {specAnalysis && activeSpecIndex === idx && (
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-4 w-48 z-50 animate-pop-in">
                        <div className="bg-[#2a2a2a] border-2 border-[#ffcc00] p-3 rounded-lg shadow-lg relative">
                          <div className="text-[10px] text-[#ffcc00] font-mono leading-tight">
                            <span className="animate-pulse">▶ </span> {specAnalysis}
                          </div>
                          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-[#2a2a2a] border-b-2 border-r-2 border-[#ffcc00] rotate-45"></div>
                        </div>
                      </div>
                    )}
                    <div className="absolute top-1 left-1 w-2 h-2 border-t-2 border-l-2 border-transparent group-hover:border-[#ffcc00] transition-all"></div>
                    <div className="absolute bottom-1 right-1 w-2 h-2 border-b-2 border-r-2 border-transparent group-hover:border-[#ffcc00] transition-all"></div>
                  </div>
                ))}
                
                {/* Console */}
                <div className="aspect-square bg-[#2a2a2a] rounded-xl col-span-1 flex flex-col p-1 border-2 border-black shadow-[2px_2px_0px_rgba(0,0,0,0.5)] overflow-hidden">
                  <div className="flex-1 bg-[#3a3a3a] rounded mb-1 flex items-center justify-center relative overflow-hidden px-1">
                    {colorCodeText ? (
                      <div className="text-[10px] text-green-400 font-mono font-bold leading-tight break-all text-center">
                        {colorCodeText}
                      </div>
                    ) : expansionLog ? (
                      <div className="absolute inset-0 bg-green-900/50 p-1 flex items-center justify-center">
                        <div className="text-[10px] text-green-400 font-mono leading-tight text-center break-words uppercase animate-pulse">
                          {expansionLog}
                        </div>
                      </div>
                    ) : (
                      <Terminal size={20} className="text-gray-500" />
                    )}
                  </div>
                  <button onClick={handleExpansion} disabled={isExpanding} className="h-8 bg-[#ffcc00] rounded flex items-center justify-center text-black font-black text-xs cursor-pointer hover:bg-yellow-300 border border-black hover:shadow-inner transition-colors disabled:opacity-50">
                    {isExpanding ? "..." : "扩容"}
                  </button>
                </div>
                
                {/* Color Controls */}
                <div className="aspect-square grid grid-cols-2 gap-1">
                  <button onClick={() => handleColorChange('prev')} className="bg-[#2a2a2a] rounded-lg flex items-center justify-center text-gray-400 hover:text-white hover:bg-black border-2 border-[#333] hover:border-gray-500 shadow-[2px_2px_0px_#000] active:shadow-none active:translate-y-[2px] active:translate-x-[2px] transition-all">◀</button>
                  <button onClick={() => handleColorChange('next')} className="bg-[#2a2a2a] rounded-lg flex items-center justify-center text-gray-400 hover:text-white hover:bg-black border-2 border-[#333] hover:border-gray-500 shadow-[2px_2px_0px_#000] active:shadow-none active:translate-y-[2px] active:translate-x-[2px] transition-all">▶</button>
                </div>
                
                <button onClick={() => setShowChat(true)} className="aspect-square bg-[#3a3a4a] rounded-xl flex items-center justify-center border-2 border-[#2a2a2a] text-gray-600 shadow-[inset_2px_2px_4px_rgba(0,0,0,0.2)] hover:bg-[#2a2a2a] hover:text-[#ffcc00] transition-colors">
                  <span className="font-bold text-xl">?</span>
                </button>
              </div>
            </div>
          </div>
          
          <button onClick={() => setShowModal(true)} className="w-full bg-[#1e40af] text-white font-black italic text-xl py-4 rounded-xl border-4 border-black shadow-[8px_8px_0px_#000] hover:translate-x-[4px] hover:translate-y-[4px] hover:shadow-[4px_4px_0px_#000] active:translate-x-[8px] active:translate-y-[8px] active:shadow-none transition-all flex items-center justify-center gap-3 hover:bg-[#ffcc00] hover:text-black">
            <span className="bg-white text-[#1e40af] px-2 text-sm rounded font-bold border-2 border-[#1e40af]">Gemini</span>
            立即体验 PRO
          </button>
        </div>
      </div>
    </div>
  );
}